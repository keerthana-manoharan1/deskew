from SkewDetect import SkewDetect
from desk import Deskew
#sd = SkewDetect(
#	input_file='C:/Users/trainee/Documents/Pictures/sample10.png',
#        output_file='C:/Users/trainee/Documents/Pictures/file1.txt',
#	
#	display_output='No')
#data=sd.determine_skew('C:/Users/trainee/Documents/Pictures/sample10.png')
#print(data.get("Estimated Angle"))

d = Deskew(
	input_file='C:/Users/trainee/Desktop/deskew/desew/image.png',
	display_image='preview the image on screen',
	output_file='C:/Users/trainee/Desktop/deskew/desew/output.png',
	r_angle=0)
d.run()


